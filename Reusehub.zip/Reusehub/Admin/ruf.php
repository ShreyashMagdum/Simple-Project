<br>
	<div class="row">
		<div class="col-sm-3"></div>
		<div class="col-sm-6">
			<!-- <?php
			if($_POST['btnupdate'])
			{
				echo '<input type="submit" name="btnedit" value="Update" class="btn btn-success">	';	
			
		    
		    }
		    else
		    {
		    	echo '<input type="submit" name="btnsubmit" value="Submit" class="btn btn-primary">';
		    }

			

			?>  -->
			 
		</div>
		<div class="col-sm-3"></div>
	</div>