
<?php include 'Admin_header.php' ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style type="text/css">
		.container
		{
			background-color: white;
			margin-top: 130px;
			padding: 70px;
			background-image:url(shopping.jpg) ;
			background-size: cover;
		}

	</style>
</head>
<body style="background-image: url(homeimg2.jpg);background-size: cover;"
>
<!-- <div class="col-sm-1"></div>
<div class="col-sm-4"> -->
	<div class="row">
		<div class="col-sm-1"></div>
		<div class="col-sm-4">
<div class="container">
	<div class="row">
		<div class="col-sm-4">
			<h1 style="box-shadow: 10px 10px 100px yellow; filter:drop-shadow(10px 10px 10px cyan);">WELCOME TO ReUseHub</h1>
			
		</div>
		<div class="col-sm-8"></div>
		
	</div>
	

</div>
<div class="col-sm-7"></div>
</div>
<!-- /div>
<div class="col-sm-7"></div> -->


</body>
</html>
<?php include 'Admin_footer.php' ?>

