<?php include'Admin_header.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style type="text/css">
		.container
		{
			background-image: url(logoutimg.png);
			background-size: cover;
		}
	</style>
</head>
<body>
	<div class="container">
		<h1>THANK YOU</h1>
	</div>


</body>
</html>
<?php include'Admin_footer.php'; ?>