<?php include'Admin_header.php';

error_reporting(0);

if (isset($_POST['btndelete']))
{
  $sql="delete from booking where id='".$_POST['txt_id']."'";
  if(mysqli_query($conn,$sql))
  {
    echo "<script>alert('Record Deleted')</script>";
  }
  else

  {
    echo "<script>alert('Record Not Deleted')</script>";
  }
}
 ?>
<div class="row">
<div class="col-sm-1"></div>
<div class="col-sm-10">
    <br>
    <h1>order List</h1>
    <br>
<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col"> Email</th>
      <th scope="col"> Contact</th>
      <th scope="col"> Quantity</th>
      <th scope="col">Address</th>
      <th scope="col">City</th>
       <th scope="col">Product Name</th>
     
     
    </tr>
  </thead>
  <tbody>
   <?php
    $i=1;
$sql=mysqli_query($conn,"select * from booking");
while ($row=mysqli_fetch_assoc($sql))
{
   echo '<tr>
   <form action="order_list.php" method="post">
   <th scope="row">'.$i++.'</th>
   <input type="hidden" name="txt_id" value="'.$row['id'].'">


    <td>'.$row['book_fname'].'</td>


  <td> '.$row['book_lname'].' </td>
  
   <td>'.$row['book_email'].'</td>

   <td>'.$row['book_number'].'</td>

   <td>'.$row['book_quanti'].'</td>

    <td>'.$row['book_address'].'</td>

 <td>'.$row['book_city'].'</td>
  <td>'.$row['book_pname'].'</td>


  

     <td> <input type="submit" name="btndelete" class="btn btn-danger" value="Delete"></td>
     </form>
    </tr>';
  }
?>
  </tbody>
</table>
</div>
<div class="col-sm-1"></div>
</div>
<?php include'Admin_footer.php'; ?>