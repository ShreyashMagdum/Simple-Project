
<?php include 'cust_header.php' ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style type="text/css">
		.container
		{
			background-color: white;
			margin-top: 130px;
			padding: 70px;
			background-image:url(shopping.jpg) ;
			background-size: cover;
		}

	</style>
</head>
<body style="background-image: url(homeimg2.jpg);background-size: cover;"
>
<!-- <div class="col-sm-1"></div>
<div class="col-sm-4"> -->
	<div class="row">
		<div class="col-sm-1"></div>
		<div class="col-sm-4">
<div class="container">
	<div class="row">
		<div class="col-sm-4">
			<h1>WELCOME TO ReUseHub</h1>
			
		</div>
		<div class="col-sm-8"></div>
		
	</div>
	

</div>
<div class="col-sm-7"></div>
</div>
<!-- /div>
<div class="col-sm-7"></div> -->


</body>
</html>
<?php include 'cust_footer.php' ?>

