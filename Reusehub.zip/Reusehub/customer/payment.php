<?php include'cust_header.php';



 ?>
 <script>
     function f1()
     {
        alert('Payment sucessfull');
     }

 </script>
<div class="row">
<div class="col-sm-4"></div>
<div class="col-sm-4">
<div class="container">
    <form action="payment.php" method="POST">

    <h2> Payment Details</h2>
    <br>
    <br>

    <div class="row">
    <div class="col-sm-12">
        <label for="">CARD NUMBER</label>
        <input type="text" placeholder="Valid Card Number" class="form-control">
    </div>
    </div>
    <br>
    <div class="row">
    <div class="col-sm-6">
        <label for="">EXPIRAY DATE</label>
        <input type="MONTH"  class="form-control">
    </div>
    <div class="col-sm-6">
        <label for="">CV CODE</label>
        <input type="text" placeholder="CVC" class="form-control">
    </div>
    </div>
    <br>
    <div class="row">
    <div class="col-sm-12">
        <label for="">CARD OWNER</label>
        <input type="text" placeholder="Card Owner Name" class="form-control">
    </div>
    </div>



    <br>
    <div class="row">
    <div class="col-sm-12">
        <input type="submit" value="Confirm Payment" class="form-control" name="payprice" onclick="f1()">
    </div>
    </div>
    </form>
</div>
</div>
<div class="col-sm-4"></div>
</div>
<?php include'cust_footer.php'; ?>